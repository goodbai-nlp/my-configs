# osx plugin

**Deprecated: use the [`macos`](https://github.com/ohmyzsh/ohmyzsh/tree/master/plugins/macos) plugin instead.**
